# Binance Spot Scanner Android
Project wrapper Android untuk file HTML scanner.
HTML asli ada di app/src/main/assets/index.html.
Internet diperlukan untuk mengambil data Binance. JavaScript dan localStorage diaktifkan.
Build APK debug dari menu Build APK pada Android Studio/Android IDE.
