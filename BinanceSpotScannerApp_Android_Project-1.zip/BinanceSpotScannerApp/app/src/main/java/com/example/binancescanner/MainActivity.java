package com.example.binancescanner;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.graphics.Color; import android.view.ViewGroup; import androidx.webkit.WebViewAssetLoader;
public class MainActivity extends Activity {
 WebView w;
 public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.setBackgroundColor(Color.BLACK); w.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
 WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(false);
 WebViewAssetLoader a=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
 w.setWebViewClient(new WebViewClient(){public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return a.shouldInterceptRequest(r.getUrl());}});
 w.loadUrl("https://appassets.androidplatform.net/assets/index.html"); setContentView(w);}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}