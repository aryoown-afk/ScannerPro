# BullishMoment — Android APK Project

Ini adalah project Android Studio yang membungkus scanner HTML menjadi aplikasi Android standalone menggunakan WebView.

## Isi
- `app/src/main/assets/index.html` — scanner HTML asli.
- `MainActivity.java` — WebView Android.
- `AndroidManifest.xml` — izin internet dan launcher.
- `build.gradle` — konfigurasi Android Gradle Plugin.

## Build APK di Android Studio
1. Install Android Studio.
2. Buka folder `BullishMoment-Android`.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan dibuat di:
   `app/build/outputs/apk/debug/app-debug.apk`

## Catatan
Scanner tetap membutuhkan koneksi internet karena mengambil data Binance API secara live. Aplikasi tidak membutuhkan Chrome atau PWA.

Jika Android Studio meminta SDK, pasang Android SDK Platform 35 dan Build-Tools yang direkomendasikan.
